package br.com.senac.teste_prova;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TesteProvaApplicationTests {

	@Test
	void contextLoads() {
	}

}
