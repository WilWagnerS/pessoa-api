package br.com.senac.teste_prova;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TesteProvaApplication {

	public static void main(String[] args) {
		SpringApplication.run(TesteProvaApplication.class, args);
	}

}
